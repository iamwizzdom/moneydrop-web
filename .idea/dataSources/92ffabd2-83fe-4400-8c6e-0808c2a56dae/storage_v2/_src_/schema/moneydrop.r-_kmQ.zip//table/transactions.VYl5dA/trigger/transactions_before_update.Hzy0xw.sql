create definer = root@localhost trigger transactions_BEFORE_UPDATE
    before update
    on transactions
    for each row
BEGIN
    IF (old.status = 1 AND new.status != 5) THEN
        SET new.status = 1;
    END IF;
END;

